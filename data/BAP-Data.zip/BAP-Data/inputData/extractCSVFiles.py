#!/usr/bin/env python
USAGE="""extractCSVFiles [_yyyS]
Extract CSVFiles from .out files, optionally only those matching the given string/regexp
"""
import os,sys,re
names = ["Begin","End","Processing","Length","Arrival"]
match="_yyyS"
if len(sys.argv) > 1:
    if sys.argv[1] == "-h":
        print USAGE
        sys.exit(1)
    else:
        match=sys.argv[1]
match = lambda string,m=re.compile(match):m.search(string)
for f in os.listdir("."):
    if not f.endswith(".out"): continue
    if not match(f): continue
    fname= f.rstrip(".out")
    parts = fname.split("_")
    parts[-1] = parts[-1].split("S")[-1] # remove prefix
    outf = "_".join(parts)+".csv"
    ofile = open(outf,'w')
    lines = open(f,'r').readlines()
    for i in range(len(lines)):
        if not lines[i].startswith("Final "): continue
        i += 2
        ofile.write("Vessels,%d\n"%(int(parts[0])))
        for j in range(5):
            vals = lines[i+j].split("=[")
            ofile.write("%s,%s\n"%(names[j],vals[1].split("]")[0]))
        ofile.close()
        break
    print f,"-->",outf
    
