import os,sys,re
for f in os.listdir("."):
    if not f.endswith(".txt"): continue
    fname = f.split(".txt")[0]
    lines = open(f,'r').readlines()
    flines = []
    #flines = filter(lambda x: len(x) == 2,flines)
    for i in range(0,len(lines)):
        if len(lines[i]) > 2:
            flines.append(lines[i])
    start = 0
    for k in range(1,11):
        ofname = "%s_%d.dat"%(fname,k)
        ofile = open(ofname,'w')
        for l in range(start,start+10):
            ofile.write(flines[l])
        ofile.close()
        start += 10
    #break
    
