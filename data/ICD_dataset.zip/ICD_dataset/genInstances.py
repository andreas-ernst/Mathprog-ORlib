import os,sys
from os.path import isfile, join

if(len(sys.argv)<2):
    print("input is requiered!")
    exit()
InDir = os.getcwd()
InDir += "/"+ sys.argv[1]


InputFiles = [f for f in os.listdir(InDir) if isfile(join(InDir, f))]

for curFile in InputFiles:
	x = curFile.split('.')
	if not (x[0].isdigit()): continue
	curFile = InDir + '/' + curFile
	with open(curFile,'r') as fp:
		C = fp.readline()
		N = int(C[:-1])
	
		for i in range(3):
			C= fp.readline();
		P = int(C[:-1])
		for i in range(4):
			C= fp.readline()
		B = int(C[:-1])
		A = P-B
		fp.close()

	for p in range(5,P+1):
		for q in range(0,p-5+1):
			if(q>B):
				break
			if(p>A and q < p-A):
				continue
			Ofil =InDir + "/"+ str(N)+"."+str(P)+"."+str(p)+"."+str(q)

			if(Ofil == curFile):
				continue

		
			with open(curFile,'r') as fp, open(Ofil,'w') as fw:
				ln  = fp.readline()
				cnt = 0
				while ln:
					if(cnt == 4):
						fw.write(str(p)+"\n")
					elif(cnt ==5):
						fw.write(str(q)+"\n")
					else:
						fw.write(ln)
					cnt +=1
					ln = fp.readline()
		
			fp.close()
			fw.close() 
