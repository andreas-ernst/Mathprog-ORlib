//Input file format:
//Parameter file format
// example: 2 3 4 5 100 200 300 
//   2 and 3: number of values for depots and trips resp
//   4 and 5: number of depots, 100, 200 and 300 number of trips
#include<algorithm> 
#include<map>
#include<vector>
#include<random>  //random number generater
#include<chrono> //time seed
#include <cstdlib> /* srand, rand */
#include <ctime> /* time */
#include<cmath>
#include<fstream>
#include<iostream>
#include<set>
#include<string>
using namespace std;

typedef map<int, vector<int> > IntVectMap;
int distanceCalculate(int, int, int, int);
int UInteger(int, int);

int main(int argc, char **argv){
	int m, n, nbInstances; //Number of depots, number of trips, and number of instances
    if (argc > 3){
       m  = atoi(argv[1]);
	   n	 = atoi(argv[2]);
	   nbInstances = atoi(argv[3]);
    }
    srand(time(NULL));
	for (int SNumber = 1; SNumber < nbInstances + 1; SNumber++) {
		cout << "Generating " << m << " " << n << " " << SNumber << endl;
		map<int,int> Vehicles;
		int MaxVehicles = round(3 + (n / (2 * m)));
		int MinVehicles = round(3 + (n / (3 * m)));
		//Number of vehicles at each depot
		for (int i = 0; i < m; i++) {
			Vehicles[i] = ceil(MinVehicles + ((double)(MaxVehicles - MinVehicles)*((double)rand() / RAND_MAX)));
		}
		//Number of locations
		int nbTripLocations = UInteger(ceil(n / 3), ceil(n / 2));
		IntVectMap TLCoordinates; //Location coordinates for relief points
		IntVectMap LCoordinates; //Location coordinates for depots
		//relief point coordinates
		//Depot coordinates
		//Fix 4 depots at the four corner
		LCoordinates[0].push_back(0);
		LCoordinates[0].push_back(0);
		LCoordinates[1].push_back(60);
		LCoordinates[1].push_back(60);
		if (m > 2) {
			LCoordinates[2].push_back(0);
			LCoordinates[2].push_back(60);
		}
		if (m > 3) {
			LCoordinates[3].push_back(60);
			LCoordinates[3].push_back(0);
		}
		if (m > 4) {
			for (int i = 4; i < m; i++) {
				int X = rand() % 60;
				int Y = rand() % 60;
				int Flag = 1;
				while (Flag == 1) {
					Flag = 0;
					for (int j = 0; j < i; j++) {
						if (X == LCoordinates[j][0] && Y == LCoordinates[j][1]) {
							Flag = 1;
							break;
						}
					}
					if (Flag == 1) {
						X = rand() % 60;
						Y = rand() % 60;
					}
				}
				LCoordinates[i].push_back(X);
				LCoordinates[i].push_back(Y);
			}
		}
		int LocationNumber = m;
		for (int i = 0; i < nbTripLocations; i++) {
			int X = rand() % 60;
			int Y = rand() % 60;
			int Flag = 0;
			for (int k = 0; k < LocationNumber; k++) {
				if (LCoordinates[k][0] == X && LCoordinates[k][1] == Y) {
					Flag = 1;
					break;
				}
			}
			if (Flag == 0) {
				LCoordinates[LocationNumber].push_back(X);
				LCoordinates[LocationNumber].push_back(Y);
				LocationNumber += 1;
			}
		}
		int nbLocations = LCoordinates.size();
		//Calculate distances between locations
		vector<vector<int> > DistanceMatrix(nbLocations, vector<int>(nbLocations));  // distance between depot locations and trip locations
		//IntMap2D TDDistanceL;
		//Between depot location and trip location
		for (int i = 0; i < nbLocations; i++) {
			for (int j = 0; j < nbLocations; j++) {
				int dist = distanceCalculate(LCoordinates[i][0], LCoordinates[i][1], LCoordinates[j][0], LCoordinates[j][1]);
				DistanceMatrix[i][j] = dist;
			}
		}
		vector<vector<int>> TripInformation(n);
		//Generate trips
		for (int i = 0; i < n; i++) {
			double prob = (double)rand() / RAND_MAX;
			if (prob < 0.6) {
				TripInformation[i].push_back(UInteger(m, nbLocations - 1));
				TripInformation[i].push_back(UInteger(300, 1200));
				TripInformation[i].push_back(TripInformation[i][0]);
				TripInformation[i].push_back(UInteger(TripInformation[i][1] + 180, TripInformation[i][1] + 300));
			}
			else {
				TripInformation[i].push_back(UInteger(m, nbLocations - 1)); // Start Locations
				double prob1 = (double)rand() / RAND_MAX;
				//Start Time
				if (prob1 < 0.15) {
					TripInformation[i].push_back(UInteger(420, 480));
				}
				else {
					if (prob1 < 0.85) {
						TripInformation[i].push_back(UInteger(480, 1020));
					}
					else {
						TripInformation[i].push_back(UInteger(1020, 1080));
					}
				}
				TripInformation[i].push_back(UInteger(m, nbLocations - 1)); // End Location
				int TripLength = DistanceMatrix[TripInformation[i][0]][TripInformation[i][2]];
				int Lower = ceil(TripInformation[i][1] + TripLength + 5);
				int Higher = ceil(TripInformation[i][1] + TripLength + 40);
				TripInformation[i].push_back(UInteger(Lower, Higher)); // End time
			}
		}
		//Create files to write input
		string S1 = "RN-" + to_string(m) + "-" + to_string(n) + "-0" + to_string(SNumber) + ".dat";
		const char * FileName1 = S1.c_str();
		ofstream out1(FileName1);
		out1 << m << " " << n << " " << nbLocations << endl;
		for (auto i = 0; i < m; i++) {
			out1 << Vehicles[i] << " ";
		}
		out1 << endl;
		for (auto i = 0; i < n; i++) {
			out1 << TripInformation[i][0] << " "
				<< TripInformation[i][1] << " "
				<< TripInformation[i][2] << " "
				<< TripInformation[i][3] << endl;
		}
		for (auto i = 0; i < nbLocations; i++) {
			for (auto j = 0; j < nbLocations; j++) {
				out1 << DistanceMatrix[i][j] << " ";
			}
			out1 << endl;
		}
		cout << "Generated Instance file: " << S1 << endl;
	}
    return 0;
}


int distanceCalculate(int x1, int y1, int x2, int y2)
{
	int  x = x1 - x2; //calculating number to square in next step
	int  y = y1 - y2;
	int sqrdist;
	int dist;
	sqrdist = pow(x, 2) + pow(y, 2);       //calculating Euclidean distance
	dist = ceil(sqrt(sqrdist));
	//cout << dist << endl;
	if(sqrdist<0){
        cout << "wrong distance " << sqrdist << endl;
	}
	return dist;
}

int UInteger(int Min, int Max){
    int R = ceil(Min + ((double)rand()/RAND_MAX)*(double)(Max-Min));
    return R;
}

