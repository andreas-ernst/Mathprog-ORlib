import random, math

# A simple problem generator for Resource Constrained Job Scheduling

# Number of instances per machine class
nSeeds = 5

# Range of machines
nMach = [3,4,5,6,7,8,9,10,12,15,18,20,25]

# Number of jobs per machine
nJobs = 10.5

# Amount of power consumed as a proportion of total power (10 * m)
pow_factor = [0.25, 0.5, 0.75]

# Using random graphs for precedences
# An edge will be inserted with the following probability
edge_prob = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]

for i in range(nSeeds):
    random.seed(i)
    for p in pow_factor:
        for e in edge_prob:
            for m in nMach:
                max_power = 10*m
                print("Generating data for instance with machine " + str(m) )
                sw = open("RCJS_" + str(i+1) + "_" + str(m) + "_" + str(math.floor(p*100)) + "_" + str(math.floor(e*100)) +".txt", 'w')
                sw.write("\\\\ machines\n" + str(m)+ "\n")
                sw.write("\\\\ max power\n" + str(max_power) + "\n")
                jid = 1
                mid = 1
                successors = {}
                s_num = 0
                for machs in range(m):
                    jobs = math.ceil(random.gauss(10.5, 1))
                    sw.write("\\\\ Jobs in machine " + str(mid) +"\n" + str(jobs) + "\n")
                    mid += 1
                    jids = []
                    for j in range(jobs):
                        rel = max(0,math.floor(random.gauss(15, 1)))
                        proc = math.floor(random.uniform(1,15))
                        due = math.ceil(random.uniform(1,110))
                        power =  math.ceil(p*random.random()*max_power)
                        weight = max(0.1,random.gauss(1.2, 0.5))
                        sw.write("J"+str(jid) + "\t" + str(rel) + "\t" + str(proc)+"\t"+str(due)+"\t" + str(power)+"\t"+str(weight)+"\n")
                        jids.append(jid)
                        jid+=1

                    # Now generate precedences between tasks on the same machine.
                    for j in range(jobs):
                        #successors[jids[j]] = []
                        for k in range(j+1, jobs):
                            if random.random() > e: continue
                            try:
                                successors[jids[j]].append(jids[k])
                                s_num += 1
                            except:
                                successors[jids[j]] = [jids[k]]
                                s_num += 1
                sw.write("\\\\ Dependencies \n" + str(s_num) +"\n")
                for s in successors:
                    for j in successors[s]:
                        sw.write(str(s) +"\t" +str(j)+"\n")
                
                sw.close()

